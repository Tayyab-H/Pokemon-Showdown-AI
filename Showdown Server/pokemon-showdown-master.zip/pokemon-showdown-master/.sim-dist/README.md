**NOTE**: This folder contains the compiled output of the `sim/` directory.
You should be editing the `.ts` files there and then running `npm run build` or
`./pokemon-showdown` to force these `.js` files to be recreated.
