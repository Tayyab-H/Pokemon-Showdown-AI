This is just a fork of babel-cli to support incremental builds.

See: https://github.com/babel/babel/pull/8877
