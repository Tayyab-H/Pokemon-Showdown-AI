<?php

$config_replay_database = [
	'server' => '127.0.0.1',
	'username' => 'username',
	'password' => 'password',
	'database' => 'replays',
	'prefix' => 'ps_',
	'charset' => 'utf8mb4',
];
