/**
 * Teambuilder panel
 *
 * @author Guangcong Luo <guangcongluo@gmail.com>
 * @license AGPLv3
 */

class TeambuilderRoom extends PSRoom {
	readonly DEFAULT_FORMAT = 'gen8' as ID;

	/**
	 * - `""` - all
	 * - `"gen[NUMBER][ID]"` - format folder
	 * - `"gen[NUMBER]"` - uncategorized gen folder
	 * - `"[ID]/"` - folder
	 * - `"/"` - not in folder
	 */
	curFolder = '';
	curFolderKeep = '';

	/**
	 * @return true to prevent line from being sent to server
	 */
	handleMessage(line: string) {
		if (!line.startsWith('/') || line.startsWith('//')) return false;
		const spaceIndex = line.indexOf(' ');
		const cmd = spaceIndex >= 0 ? line.slice(1, spaceIndex) : line.slice(1);
		const target = spaceIndex >= 0 ? line.slice(spaceIndex + 1) : '';
		switch (cmd) {
		case 'newteam': {
			if (target === 'bottom') {
				PS.teams.push(this.createTeam());
			} else {
				PS.teams.unshift(this.createTeam());
			}
			this.update(null);
			return true;
		} case 'deleteteam': {
			const team = PS.teams.byKey[target];
			if (team) PS.teams.delete(team);
			this.update(null);
			return true;
		} case 'undeleteteam': {
			PS.teams.undelete();
			this.update(null);
			return true;
		}}

		// unrecognized command
		alert(`Unrecognized command: ${line}`);
		return true;
	}

	createTeam(copyFrom?: Team): Team {
		if (copyFrom) {
			return {
				name: `Copy of ${copyFrom.name}`,
				format: copyFrom.format,
				folder: copyFrom.folder,
				packedTeam: copyFrom.packedTeam,
				iconCache: null,
				key: '',
			};
		} else {
			const format = this.curFolder && !this.curFolder.endsWith('/') ? this.curFolder as ID : this.DEFAULT_FORMAT;
			const folder = this.curFolder.endsWith('/') ? this.curFolder.slice(0, -1) : '';
			return {
				name: `Untitled ${PS.teams.list.length + 1}`,
				format,
				folder,
				packedTeam: '',
				iconCache: null,
				key: '',
			};
		}
	}
}

class TeambuilderPanel extends PSRoomPanel<TeambuilderRoom> {
	selectFolder = (e: MouseEvent) => {
		const room = this.props.room;
		let elem = e.target as HTMLElement | null;
		let folder: string | null = null;
		while (elem) {
			if (elem.className === 'selectFolder') {
				folder = elem.getAttribute('data-value') || '';
				break;
			} else if (elem.className === 'folderlist') {
				return;
			}
			elem = elem.parentElement;
		}
		if (folder === null) return;
		room.curFolderKeep = folder;
		room.curFolder = folder;
		e.preventDefault();
		e.stopImmediatePropagation();
		this.forceUpdate();
	};
	renderFolderList() {
		const room = this.props.room;
		// The folder list isn't actually saved anywhere:
		// it's regenerated anew from the team list every time.

		// (This is why folders you create will automatically disappear
		// if you leave them without adding anything to them.)

		const folderTable: {[folder: string]: 1 | undefined} = {'': 1};
		const folders: string[] = [];
		for (const team of PS.teams.list) {
			const folder = team.folder;
			if (folder && !(`${folder}/` in folderTable)) {
				folders.push(`${folder}/`);
				folderTable[`${folder}/`] = 1;
				if (!('/' in folderTable)) {
					folders.push('/');
					folderTable['/'] = 1;
				}
			}

			const format = team.format || room.DEFAULT_FORMAT;
			if (!(format in folderTable)) {
				folders.push(format);
				folderTable[format] = 1;
			}
		}
		if (!(room.curFolderKeep in folderTable)) {
			folderTable[room.curFolderKeep] = 1;
			folders.push(room.curFolderKeep);
		}
		if (!(room.curFolder in folderTable)) {
			folderTable[room.curFolder] = 1;
			folders.push(room.curFolder);
		}

		PSUtils.sortBy(folders, folder => [
			folder.endsWith('/') ? 10 : -parseInt(folder.charAt(3), 10),
			folder,
		]);

		let renderedFormatFolders = [
			<div class="foldersep"></div>,
			<TeamFolder cur={false} value="+">
				<i class="fa fa-plus"></i><em>(add format folder)</em>
			</TeamFolder>,
		];

		let renderedFolders: preact.ComponentChild[] = [];

		let gen = -1;
		for (let format of folders) {
			const newGen = format.endsWith('/') ? 0 : parseInt(format.charAt(3), 10);
			if (gen !== newGen) {
				gen = newGen;
				if (gen === 0) {
					renderedFolders.push(...renderedFormatFolders);
					renderedFormatFolders = [];
					renderedFolders.push(<div class="foldersep"></div>);
					renderedFolders.push(<div class="folder"><h3>Folders</h3></div>);
				} else {
					renderedFolders.push(<div class="folder"><h3>Gen {gen}</h3></div>);
				}
			}
			const folderOpenIcon = room.curFolder === format ? 'fa-folder-open' : 'fa-folder';
			if (gen === 0) {
				renderedFolders.push(<TeamFolder cur={room.curFolder === format} value={format}>
					<i class={
						`fa ${folderOpenIcon}${format === '/' ? '-o' : ''}`
					}></i>
					{format.slice(0, -1) || '(uncategorized)'}
				</TeamFolder>);
				continue;
			}

			renderedFolders.push(<TeamFolder cur={room.curFolder === format} value={format}>
				<i class={`fa ${folderOpenIcon}-o`}></i>
				{format.slice(4) || '(uncategorized)'}
			</TeamFolder>);
		}
		renderedFolders.push(...renderedFormatFolders);

		return <div class="folderlist" onClick={this.selectFolder}>
			<div class="folderlistbefore"></div>

			<TeamFolder cur={!room.curFolder} value="">
				<em>(all)</em>
			</TeamFolder>
			{renderedFolders}
			<div class="foldersep"></div>
			<TeamFolder cur={false} value="++">
				<i class="fa fa-plus"></i><em>(add folder)</em>
			</TeamFolder>

			<div class="folderlistafter"></div>
		</div>;
	}

	render() {
		const room = this.props.room;
		let teams: (Team | null)[];

		let filterFolder: string | null = null;
		let filterFormat: string | null = null;
		if (room.curFolder) {
			if (room.curFolder.slice(-1) === '/') {
				filterFolder = room.curFolder.slice(0, -1);
				teams = PS.teams.list.filter(team => team.folder === filterFolder);
			} else {
				filterFormat = room.curFolder;
				teams = PS.teams.list.filter(team => team.format === filterFormat);
			}
		} else {
			teams = PS.teams.list.slice();
		}

		if (PS.teams.deletedTeams.length) {
			const undeleteIndex = PS.teams.deletedTeams[PS.teams.deletedTeams.length - 1][1];
			teams.splice(undeleteIndex, 0, null);
		}

		return <PSPanelWrapper room={room}>
			<div class="folderpane">
				{this.renderFolderList()}
			</div>
			<div class="teampane">
				{filterFolder ?
					<h2>
						<i class="fa fa-folder-open"></i> {filterFolder} {}
						<button class="button small" style="margin-left:5px" name="renameFolder">
							<i class="fa fa-pencil"></i> Rename
						</button> {}
						<button class="button small" style="margin-left:5px" name="promptDeleteFolder">
							<i class="fa fa-times"></i> Remove
						</button>
					</h2>
				: filterFolder === '' ?
					<h2><i class="fa fa-folder-open-o"></i> Teams not in any folders</h2>
				: filterFormat ?
					<h2><i class="fa fa-folder-open-o"></i> {filterFormat}</h2>
				:
					<h2>All Teams</h2>
				}
				<p>
					<button name="cmd" value="/newteam" class="button big"><i class="fa fa-plus-circle"></i> New Team</button>
				</p>
				<ul class="teamlist">
					{teams.map(team => team ? (
						<li key={team.key}>
							<TeamBox team={team} /> {}
							<button name="cmd" value={`/deleteteam ${team.key}`}><i class="fa fa-trash"></i> Delete</button>
						</li>
					) : (
						<li key="undelete">
							<button name="cmd" value={`/undeleteteam`}><i class="fa fa-undo"></i> Undo delete</button>
						</li>
					))}
				</ul>
				<p>
					<button name="cmd" value="/newteam bottom" class="button"><i class="fa fa-plus-circle"></i> New Team</button>
				</p>
			</div>
		</PSPanelWrapper>;
	}
}

PS.roomTypes['teambuilder'] = {
	Model: TeambuilderRoom,
	Component: TeambuilderPanel,
	title: "Teambuilder",
};
